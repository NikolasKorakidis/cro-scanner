// server/services/psiService.js
const axios = require('axios');

const getPageSpeedData = async (url) => {
  const apiKey = process.env.PSI_API_KEY;
  const endpoint = `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${encodeURIComponent(
    url
  )}&key=${apiKey}&strategy=mobile`;

  const { data } = await axios.get(endpoint);
  const lighthouse = data.lighthouseResult;

  // Extract high-level scores
  const scores = {
    performance: Math.round(lighthouse.categories.performance.score * 100),
    accessibility: Math.round(lighthouse.categories.accessibility.score * 100),
    seo: Math.round(lighthouse.categories.seo.score * 100),
    bestPractices: Math.round(lighthouse.categories['best-practices'].score * 100),
  };

  // Extract core metrics
  const metrics = {
    lcp: lighthouse.audits['largest-contentful-paint'].displayValue,
    tbt: lighthouse.audits['total-blocking-time'].displayValue,
    speedIndex: lighthouse.audits['speed-index'].displayValue,
    fcp: lighthouse.audits['first-contentful-paint'].displayValue,
  };

  // Extract top 5 opportunities from Lighthouse audits
  const opportunities = lighthouse.audits;
  const topOpportunities = Object.values(opportunities)
    .filter((item) => item.score !== null && item.details?.type === 'opportunity')
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((item) => ({
      title: item.title,
      description: item.description,
    }));

  return {
    scores,
    metrics,
    topOpportunities,
  };
};

module.exports = { getPageSpeedData };
